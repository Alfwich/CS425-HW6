#ifndef UTILS_H
#define UTILS_H

#include "tspsolver.h"

void PrintMatrix(const TSPSolver::TMatrix& matrix); // Print a cost matrix

#endif
